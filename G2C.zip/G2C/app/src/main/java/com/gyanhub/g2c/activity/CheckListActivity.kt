package com.gyanhub.g2c.activity

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase
import com.gyanhub.g2c.R
import com.gyanhub.g2c.adapter.CheckListAdapter
import com.gyanhub.g2c.adapter.ClickOnList
import com.gyanhub.g2c.databinding.ActivityCheckListBinding
import com.gyanhub.g2c.model.Check_List_Model
import java.util.*
import kotlin.collections.ArrayList

class CheckListActivity : AppCompatActivity(), ClickOnList {
    private lateinit var binding: ActivityCheckListBinding
    private var list = arrayListOf<Check_List_Model>()
    private lateinit var database: DatabaseReference

    private lateinit var dialog: Dialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        database = FirebaseDatabase.getInstance().getReference("List-DB")
        dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        getList()

        binding.btnAdd.setOnClickListener {
            showDialog(UUID.randomUUID().toString())
        }
    }

    private fun rcViewSet() {
        val decorator = DividerItemDecoration(this, LinearLayoutManager.VERTICAL)
        ResourcesCompat.getDrawable(resources, R.drawable.file, null)?.let {
            decorator.setDrawable(it)
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.addItemDecoration(decorator)
        val adapter = CheckListAdapter(list, this)
        binding.recyclerView.adapter = adapter
    }

    override fun onClick(position: Int) {
        startActivity(Intent(this, BookingDetailActivity::class.java))
    }

    override fun onLongClick(id: String) {
        showDeleteDialog(id)
    }

    private fun showDialog(id: String) {
        dialog.setContentView(R.layout.layout_custome_diloge)
        val list: EditText = dialog.findViewById(R.id.eTxtList)
        val yesBtn: Button = dialog.findViewById(R.id.btnUpdate)
        yesBtn.setOnClickListener {
            database.child(id).setValue(Check_List_Model(id, list.text.toString()))
                .addOnSuccessListener {
                    Toast.makeText(this, "Uploading successfully", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Uploading Failed", Toast.LENGTH_SHORT).show()
                }
        }
        dialog.show()
    }

    private fun showDeleteDialog(id:String) {
        dialog.setContentView(R.layout.layout_custome_delete_diloge)
        val yesBtn: Button = dialog.findViewById(R.id.btnDelete)
        yesBtn.setOnClickListener {
           database.child(id).removeValue().addOnSuccessListener {
                Toast.makeText(this, "Deleting successful", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.addOnFailureListener{
                Toast.makeText(this, "Deleting failed", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun getList() {

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                list.clear()
                if (snapshot.exists()) {
                    for (data in snapshot.children) {
                        val lists = data.getValue(Check_List_Model::class.java)
                        list.add(lists!!)
                    }
                    rcViewSet()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("ANKIT", "Loading Failed", error.toException())
            }

        })
    }
}


