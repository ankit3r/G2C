package com.gyanhub.g2c.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gyanhub.g2c.R
import com.gyanhub.g2c.model.Check_List_Model

class CheckListAdapter(
    private val list: ArrayList<Check_List_Model>,
    private val click: ClickOnList
) :
    RecyclerView.Adapter<CheckListAdapter.CheckListViewHolder>() {
    class CheckListViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val listValue: TextView = view.findViewById(R.id.txtListValue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CheckListViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_check_list_item, parent, false)
        return CheckListViewHolder(view)
    }

    override fun onBindViewHolder(holder: CheckListViewHolder, position: Int) {
        val currentList = list[position]
        holder.listValue.text = currentList.value
        holder.itemView.setOnLongClickListener {selectItem(currentList.id)}
        holder.itemView.setOnClickListener {
            click.onClick(position)
        }
    }
    private fun selectItem(id: String):Boolean{
        click.onLongClick(id)
        return true
    }

    override fun getItemCount(): Int {
        return list.size
    }
}

interface ClickOnList {
    fun onClick(position: Int)
    fun onLongClick(id: String)
}