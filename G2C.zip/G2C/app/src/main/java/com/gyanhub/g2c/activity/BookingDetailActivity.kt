package com.gyanhub.g2c.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gyanhub.g2c.databinding.ActivityBookingDetailBinding

class BookingDetailActivity : AppCompatActivity() {
    private lateinit var binding:ActivityBookingDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}