package com.gyanhub.g2c.model

data class Check_List_Model(
    val id: String,
    val value: String,
){
    constructor() : this("", "")
}
